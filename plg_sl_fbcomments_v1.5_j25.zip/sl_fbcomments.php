<?php
/**
 * @copyright	Copyright (c) 2013 Skyline Software (http://extstore.com). All rights reserved.
 * @license		GNU General Public License version 2 or later; see LICENSE.txt
 */

// no direct access
defined('_JEXEC') or die();

jimport('joomla.plugin.plugin');

/**
 * System - Facebook Comments Plugin
 *
 * @package		Joomla.Plugin
 * @subpakage	Skyline.FBComments
 */
class plgSystemSL_FBComments extends JPlugin {

	/**
	 * Constructor.
	 *
	 * @param 	$subject
	 * @param	array $config
	 */
	function __construct(&$subject, $config = array()) {
		// call parent constructor
		parent::__construct($subject, $config);
	}

	/**
	 * onAfterInitialise hook.
	 */
	public function onAfterInitialise() {
		$condition	= JRequest::getVar('sl_fbcomments') == 'notify';

		if ($condition) {
			// get params
			$recipient		= str_replace(' ', '', $this->params->get('recipient'));
			if ($recipient) {
				jimport('joomla.mail.helper');

				$href			= JRequest::getString('href');
				$app			= JFactory::getApplication();
				$email_from		= $app->getCfg('mailfrom');
				$email_fromname	= $app->getCfg('fromname');
				$email_subject	= $this->params->get('email_subject');
				$email_body		= str_replace('{href}', $href, $this->params->get('email_body'));

				$recipients	= explode(',', $recipient);

				foreach ($recipients as $recipient) {
					if (JMailHelper::isEmailAddress($recipient)) {
						JFactory::getMailer()->sendMail($email_from, $email_fromname, $recipient, $email_subject, $email_body);
					}
				}
			}

			exit;
		}
	}

	/**
	 * onContentBeforeDisplay hook.
	 */
	public function onContentAfterDisplay($context, &$item, &$params, $page = 0) {
		$view	= JRequest::getVar('view');

		if ($view == 'article' && $context == 'com_content.article') {
			$enable	= $this->params->get('enable', 1);

			// check if comments is disabled
			if (strpos($item->text, '{sl_nofbcomments}') !== false) {
				$item->text = str_replace(array('{sl_nofbcomments}', '{sl_fbcomments}'), array('', ''), $item->text);
				return;
			} else {
				$href			= JRoute::_(ContentHelperRoute::getArticleRoute($item->slug, $item->catslug));
				$domain			= str_replace(JURI::base(true) . '/', '', JURI::base());
				$href			= $domain . $href;
				$width			= $this->params->get('width', 500);
				$num_posts		= $this->params->get('num_posts', 10);
				$colorscheme	= $this->params->get('colorscheme', 'light');
				$app_id			= $this->params->get('app_id');
				$document		= JFactory::getDocument();

				$document->addCustomTag('<meta property="fb:app_id" content="' . $app_id . '"/>');

				$content	= <<<COMMENTS
<fb:comments
	publish_feed="true"
	numposts="$num_posts"
	width="$width"
	href="$href"
	colorscheme="$colorscheme"
></fb:comments>
COMMENTS;
				if (strpos($item->text, '{sl_fbcomments}') !== false) {
					$item->text = str_replace('{sl_fbcomments}', $content, $item->text);
				} else if ($enable) {
					return $content;
				}
			}
		}
	}


	/**
	 * onAfterRender Hook.
	 */
	public function onAfterRender() {
		$body	= JResponse::getBody();
		// search for id="fb_root"
		if (strpos($body, 'id="fb-root"') === false) {
			JHtml::_('behavior.framework');

			$url	= JRoute::_('index.php');
			$app_id	= $this->params->get('app_id');

			// add facebook script
			$fbsdk	= <<<FBSCRIPT
$0
<div id="fb-root"></div>
<script>
(function(d, s, id) {
	var js, fjs = d.getElementsByTagName(s)[0];
	if (d.getElementById(id)) return;
	js = d.createElement(s); js.id = id;
	js.src = "//connect.facebook.net/en_US/all.js#xfbml=1";
	fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));

window.fbAsyncInit = function() {
	FB.init({
		appId:	'$app_id',
		status:	true,
		cookie:	true,
		xfbml: true
	});

	FB.Event.subscribe('comment.create', function(response) {
		new Request({
			method:		'post',
			url:		'$url',
			data:		'sl_fbcomments=notify&href=' + response.href
		}).send();
	});
};
</script>
FBSCRIPT;

			$body = preg_replace('/<body[^>]*>/', $fbsdk, $body);
			JResponse::setBody($body);
		}
	}
}